# Be sure to restart your server when you modify this file.

# ActiveSupport::Reloader.to_prepare do
#   ApplicationController.renderer.defaults.merge!(
#     http_host: 'example.org',
#     https: false
#   )
# end

Refile.secret_key = '9a844764fa67fddc19b14b31d1fc7b7ec036aba0d6153e25b93b293f579c3b36613b2a8f6d66b63f9531141b8e7f3354fdcd81fc4d3c43f379c3d4bbb754040e'
